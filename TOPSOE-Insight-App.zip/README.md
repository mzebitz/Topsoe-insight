# TOPSOE Insight

Dette er en webapp til at hjælpe brugere med at udfylde en personlig farveprofil baseret på Insight Discovery-modellen.

## Funktioner
- Dynamisk farveprofil
- Sprogskift (DA/EN)
- Brugeren kan gemme og redigere sine svar
- Admin-overblik (kommer i næste version)

## Deployment
Kan hostes gratis på Netlify, Vercel eller GitHub Pages.

## Udvikling
HTML/JS med modulstruktur. React-version kommer senere.
