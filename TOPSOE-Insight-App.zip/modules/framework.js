export function createApp(root) {
  root.innerHTML = `
    <h1>Velkommen til TOPSOE Insight</h1>
    <p>Udfyld din farveprofil og få indsigt i din personlighedstype.</p>
    <!-- Appens UI her -->
  `;
}